import{P as Ne,g as We,U as Ve,S as Xe,b as Ye,n as je,l as qe,W as Qe,C as Je,D as Ke,o as j,N as en}from"./reticle-CFmphrY9.js";/*!
fflate - fast JavaScript compression/decompression
<https://101arrowz.github.io/fflate>
Licensed under MIT. https://github.com/101arrowz/fflate/blob/master/LICENSE
version 0.8.2
*/var C=Uint8Array,k=Uint16Array,Me=Int32Array,we=new C([0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0,0,0,0]),xe=new C([0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13,0,0]),Te=new C([16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15]),Fe=function(e,n){for(var t=new k(31),r=0;r<31;++r)t[r]=n+=1<<e[r-1];for(var o=new Me(t[30]),r=1;r<30;++r)for(var a=t[r];a<t[r+1];++a)o[a]=a-t[r]<<5|r;return{b:t,r:o}},De=Fe(we,2),nn=De.b,he=De.r;nn[28]=258,he[258]=28;var rn=Fe(xe,0),Ce=rn.r,pe=new k(32768);for(var M=0;M<32768;++M){var Z=(M&43690)>>1|(M&21845)<<1;Z=(Z&52428)>>2|(Z&13107)<<2,Z=(Z&61680)>>4|(Z&3855)<<4,pe[M]=((Z&65280)>>8|(Z&255)<<8)>>1}var ne=function(e,n,t){for(var r=e.length,o=0,a=new k(n);o<r;++o)e[o]&&++a[e[o]-1];var s=new k(n);for(o=1;o<n;++o)s[o]=s[o-1]+a[o-1]<<1;var u;if(t){u=new k(1<<n);var l=15-n;for(o=0;o<r;++o)if(e[o])for(var f=o<<4|e[o],i=n-e[o],c=s[e[o]-1]++<<i,h=c|(1<<i)-1;c<=h;++c)u[pe[c]>>l]=f}else for(u=new k(r),o=0;o<r;++o)e[o]&&(u[o]=pe[s[e[o]-1]++]>>15-e[o]);return u},N=new C(288);for(var M=0;M<144;++M)N[M]=8;for(var M=144;M<256;++M)N[M]=9;for(var M=256;M<280;++M)N[M]=7;for(var M=280;M<288;++M)N[M]=8;var oe=new C(32);for(var M=0;M<32;++M)oe[M]=5;var tn=ne(N,9,0),on=ne(oe,5,0),Ie=function(e){return(e+7)/8|0},Oe=function(e,n,t){return(t==null||t>e.length)&&(t=e.length),new C(e.subarray(n,t))},an=["unexpected EOF","invalid block type","invalid length/literal","invalid distance","stream finished","no stream handler",,"no callback","invalid UTF-8 data","extra field too long","date not in range 1980-2099","filename too long","stream finishing","invalid zip data"],se=function(e,n,t){var r=new Error(n||an[e]);if(r.code=e,Error.captureStackTrace&&Error.captureStackTrace(r,se),!t)throw r;return r},H=function(e,n,t){t<<=n&7;var r=n/8|0;e[r]|=t,e[r+1]|=t>>8},J=function(e,n,t){t<<=n&7;var r=n/8|0;e[r]|=t,e[r+1]|=t>>8,e[r+2]|=t>>16},ce=function(e,n){for(var t=[],r=0;r<e.length;++r)e[r]&&t.push({s:r,f:e[r]});var o=t.length,a=t.slice();if(!o)return{t:ze,l:0};if(o==1){var s=new C(t[0].s+1);return s[t[0].s]=1,{t:s,l:1}}t.sort(function(P,U){return P.f-U.f}),t.push({s:-1,f:25001});var u=t[0],l=t[1],f=0,i=1,c=2;for(t[0]={s:-1,f:u.f+l.f,l:u,r:l};i!=o-1;)u=t[t[f].f<t[c].f?f++:c++],l=t[f!=i&&t[f].f<t[c].f?f++:c++],t[i++]={s:-1,f:u.f+l.f,l:u,r:l};for(var h=a[0].s,r=1;r<o;++r)a[r].s>h&&(h=a[r].s);var v=new k(h+1),g=ge(t[i-1],v,0);if(g>n){var r=0,$=0,x=g-n,E=1<<x;for(a.sort(function(U,w){return v[w.s]-v[U.s]||U.f-w.f});r<o;++r){var F=a[r].s;if(v[F]>n)$+=E-(1<<g-v[F]),v[F]=n;else break}for($>>=x;$>0;){var b=a[r].s;v[b]<n?$-=1<<n-v[b]++-1:++r}for(;r>=0&&$;--r){var m=a[r].s;v[m]==n&&(--v[m],++$)}g=n}return{t:new C(v),l:g}},ge=function(e,n,t){return e.s==-1?Math.max(ge(e.l,n,t+1),ge(e.r,n,t+1)):n[e.s]=t},Pe=function(e){for(var n=e.length;n&&!e[--n];);for(var t=new k(++n),r=0,o=e[0],a=1,s=function(l){t[r++]=l},u=1;u<=n;++u)if(e[u]==o&&u!=n)++a;else{if(!o&&a>2){for(;a>138;a-=138)s(32754);a>2&&(s(a>10?a-11<<5|28690:a-3<<5|12305),a=0)}else if(a>3){for(s(o),--a;a>6;a-=6)s(8304);a>2&&(s(a-3<<5|8208),a=0)}for(;a--;)s(o);a=1,o=e[u]}return{c:t.subarray(0,r),n}},K=function(e,n){for(var t=0,r=0;r<n.length;++r)t+=e[r]*n[r];return t},be=function(e,n,t){var r=t.length,o=Ie(n+2);e[o]=r&255,e[o+1]=r>>8,e[o+2]=e[o]^255,e[o+3]=e[o+1]^255;for(var a=0;a<r;++a)e[o+a+4]=t[a];return(o+4+r)*8},Ee=function(e,n,t,r,o,a,s,u,l,f,i){H(n,i++,t),++o[256];for(var c=ce(o,15),h=c.t,v=c.l,g=ce(a,15),$=g.t,x=g.l,E=Pe(h),F=E.c,b=E.n,m=Pe($),P=m.c,U=m.n,w=new k(19),d=0;d<F.length;++d)++w[F[d]&31];for(var d=0;d<P.length;++d)++w[P[d]&31];for(var p=ce(w,7),A=p.t,W=p.l,R=19;R>4&&!A[Te[R-1]];--R);var V=f+5<<3,D=K(o,N)+K(a,oe)+s,I=K(o,h)+K(a,$)+s+14+3*R+K(w,A)+2*w[16]+3*w[17]+7*w[18];if(l>=0&&V<=D&&V<=I)return be(n,i,e.subarray(l,l+f));var z,y,O,L;if(H(n,i,1+(I<D)),i+=2,I<D){z=ne(h,v,0),y=h,O=ne($,x,0),L=$;var ie=ne(A,W,0);H(n,i,b-257),H(n,i+5,U-1),H(n,i+10,R-4),i+=14;for(var d=0;d<R;++d)H(n,i+3*d,A[Te[d]]);i+=3*R;for(var G=[F,P],Q=0;Q<2;++Q)for(var X=G[Q],d=0;d<X.length;++d){var B=X[d]&31;H(n,i,ie[B]),i+=A[B],B>15&&(H(n,i,X[d]>>5&127),i+=X[d]>>12)}}else z=tn,y=N,O=on,L=oe;for(var d=0;d<u;++d){var _=r[d];if(_>255){var B=_>>18&31;J(n,i,z[B+257]),i+=y[B+257],B>7&&(H(n,i,_>>23&31),i+=we[B]);var Y=_&31;J(n,i,O[Y]),i+=L[Y],Y>3&&(J(n,i,_>>5&8191),i+=xe[Y])}else J(n,i,z[_]),i+=y[_]}return J(n,i,z[256]),i+y[256]},sn=new Me([65540,131080,131088,131104,262176,1048704,1048832,2114560,2117632]),ze=new C(0),un=function(e,n,t,r,o,a){var s=a.z||e.length,u=new C(r+s+5*(1+Math.ceil(s/7e3))+o),l=u.subarray(r,u.length-o),f=a.l,i=(a.r||0)&7;if(n){i&&(l[0]=a.r>>3);for(var c=sn[n-1],h=c>>13,v=c&8191,g=(1<<t)-1,$=a.p||new k(32768),x=a.h||new k(g+1),E=Math.ceil(t/3),F=2*E,b=function(fe){return(e[fe]^e[fe+1]<<E^e[fe+2]<<F)&g},m=new Me(25e3),P=new k(288),U=new k(32),w=0,d=0,p=a.i||0,A=0,W=a.w||0,R=0;p+2<s;++p){var V=b(p),D=p&32767,I=x[V];if($[D]=I,x[V]=D,W<=p){var z=s-p;if((w>7e3||A>24576)&&(z>423||!f)){i=Ee(e,l,0,m,P,U,d,A,R,p-R,i),A=w=d=0,R=p;for(var y=0;y<286;++y)P[y]=0;for(var y=0;y<30;++y)U[y]=0}var O=2,L=0,ie=v,G=D-I&32767;if(z>2&&V==b(p-G))for(var Q=Math.min(h,z)-1,X=Math.min(32767,p),B=Math.min(258,z);G<=X&&--ie&&D!=I;){if(e[p+O]==e[p+O-G]){for(var _=0;_<B&&e[p+_]==e[p+_-G];++_);if(_>O){if(O=_,L=G,_>Q)break;for(var Y=Math.min(G,_-2),me=0,y=0;y<Y;++y){var ue=p-G+y&32767,Ze=$[ue],ye=ue-Ze&32767;ye>me&&(me=ye,I=ue)}}}D=I,I=$[D],G+=D-I&32767}if(L){m[A++]=268435456|he[O]<<18|Ce[L];var Se=he[O]&31,_e=Ce[L]&31;d+=we[Se]+xe[_e],++P[257+Se],++U[_e],W=p+O,++w}else m[A++]=e[p],++P[e[p]]}}for(p=Math.max(p,W);p<s;++p)m[A++]=e[p],++P[e[p]];i=Ee(e,l,f,m,P,U,d,A,R,p-R,i),f||(a.r=i&7|l[i/8|0]<<3,i-=7,a.h=x,a.p=$,a.i=p,a.w=W)}else{for(var p=a.w||0;p<s+f;p+=65535){var le=p+65535;le>=s&&(l[i/8|0]=f,le=s),i=be(l,i+1,e.subarray(p,le))}a.i=s}return Oe(u,0,r+Ie(i)+o)},ln=function(){for(var e=new Int32Array(256),n=0;n<256;++n){for(var t=n,r=9;--r;)t=(t&1&&-306674912)^t>>>1;e[n]=t}return e}(),fn=function(){var e=-1;return{p:function(n){for(var t=e,r=0;r<n.length;++r)t=ln[t&255^n[r]]^t>>>8;e=t},d:function(){return~e}}},cn=function(e,n,t,r,o){if(!o&&(o={l:1},n.dictionary)){var a=n.dictionary.subarray(-32768),s=new C(a.length+e.length);s.set(a),s.set(e,a.length),e=s,o.w=a.length}return un(e,n.level==null?6:n.level,n.mem==null?o.l?Math.ceil(Math.max(8,Math.min(13,Math.log(e.length)))*1.5):20:12+n.mem,t,r,o)},Ge=function(e,n){var t={};for(var r in e)t[r]=e[r];for(var r in n)t[r]=n[r];return t},S=function(e,n,t){for(;t;++n)e[n]=t,t>>>=8};function vn(e,n){return cn(e,n||{},0,0)}var Be=function(e,n,t,r){for(var o in e){var a=e[o],s=n+o,u=r;Array.isArray(a)&&(u=Ge(r,a[1]),a=a[0]),a instanceof C?t[s]=[a,u]:(t[s+="/"]=[new C(0),u],Be(a,s,t,r))}},Ue=typeof TextEncoder<"u"&&new TextEncoder,hn=typeof TextDecoder<"u"&&new TextDecoder,pn=0;try{hn.decode(ze,{stream:!0}),pn=1}catch{}function ae(e,n){var t;if(Ue)return Ue.encode(e);for(var r=e.length,o=new C(e.length+(e.length>>1)),a=0,s=function(f){o[a++]=f},t=0;t<r;++t){if(a+5>o.length){var u=new C(a+8+(r-t<<1));u.set(o),o=u}var l=e.charCodeAt(t);l<128||n?s(l):l<2048?(s(192|l>>6),s(128|l&63)):l>55295&&l<57344?(l=65536+(l&1047552)|e.charCodeAt(++t)&1023,s(240|l>>18),s(128|l>>12&63),s(128|l>>6&63),s(128|l&63)):(s(224|l>>12),s(128|l>>6&63),s(128|l&63))}return Oe(o,0,a)}var de=function(e){var n=0;if(e)for(var t in e){var r=e[t].length;r>65535&&se(9),n+=r+4}return n},Ae=function(e,n,t,r,o,a,s,u){var l=r.length,f=t.extra,i=u&&u.length,c=de(f);S(e,n,s!=null?33639248:67324752),n+=4,s!=null&&(e[n++]=20,e[n++]=t.os),e[n]=20,n+=2,e[n++]=t.flag<<1|(a<0&&8),e[n++]=o&&8,e[n++]=t.compression&255,e[n++]=t.compression>>8;var h=new Date(t.mtime==null?Date.now():t.mtime),v=h.getFullYear()-1980;if((v<0||v>119)&&se(10),S(e,n,v<<25|h.getMonth()+1<<21|h.getDate()<<16|h.getHours()<<11|h.getMinutes()<<5|h.getSeconds()>>1),n+=4,a!=-1&&(S(e,n,t.crc),S(e,n+4,a<0?-a-2:a),S(e,n+8,t.size)),S(e,n+12,l),S(e,n+14,c),n+=16,s!=null&&(S(e,n,i),S(e,n+6,t.attrs),S(e,n+10,s),n+=14),e.set(r,n),n+=l,c)for(var g in f){var $=f[g],x=$.length;S(e,n,+g),S(e,n+2,x),e.set($,n+4),n+=4+x}return i&&(e.set(u,n),n+=i),n},gn=function(e,n,t,r,o){S(e,n,101010256),S(e,n+8,t),S(e,n+10,t),S(e,n+12,r),S(e,n+16,o)};function dn(e,n){n||(n={});var t={},r=[];Be(e,"",t,n);var o=0,a=0;for(var s in t){var u=t[s],l=u[0],f=u[1],i=f.level==0?0:8,c=ae(s),h=c.length,v=f.comment,g=v&&ae(v),$=g&&g.length,x=de(f.extra);h>65535&&se(11);var E=i?vn(l,f):l,F=E.length,b=fn();b.p(l),r.push(Ge(f,{size:l.length,crc:b.d(),c:E,f:c,m:g,u:h!=s.length||g&&v.length!=$,o,compression:i})),o+=30+h+x+F,a+=76+2*(h+x)+($||0)+F}for(var m=new C(a+22),P=o,U=a-o,w=0;w<r.length;++w){var c=r[w];Ae(m,c.o,c,c.f,c.u,c.c.length);var d=30+c.f.length+de(c.extra);m.set(c.c,c.o+d),Ae(m,o,c,c.f,c.u,c.c.length,c.o,c.m),o+=16+d+(c.m?c.m.length:0)}return gn(m,o,r.length,U,P),m}let ee,ve,q,re;function $n(e,n=1/0,t=null){ve||(ve=new Ne(2,2,1,1)),q||(q=new We({uniforms:{blitTexture:new Ve(e)},vertexShader:`
			varying vec2 vUv;
			void main(){
				vUv = uv;
				gl_Position = vec4(position.xy * 1.0,0.,.999999);
			}`,fragmentShader:`
			uniform sampler2D blitTexture; 
			varying vec2 vUv;

			void main(){ 
				gl_FragColor = vec4(vUv.xy, 0, 1);
				
				#ifdef IS_SRGB
				gl_FragColor = sRGBTransferOETF( texture2D( blitTexture, vUv) );
				#else
				gl_FragColor = texture2D( blitTexture, vUv);
				#endif
			}`})),q.uniforms.blitTexture.value=e,q.defines.IS_SRGB=e.colorSpace==Xe,q.needsUpdate=!0,re||(re=new Ye(ve,q),re.frustumCulled=!1);const r=new je,o=new qe;o.add(re),t===null&&(t=ee=new Qe({antialias:!1}));const a=Math.min(e.image.width,n),s=Math.min(e.image.height,n);t.setSize(a,s),t.clear(),t.render(o,r);const u=document.createElement("canvas"),l=u.getContext("2d");u.width=a,u.height=s,l.drawImage(t.domElement,0,0,a,s);const f=new Je(u);return f.minFilter=e.minFilter,f.magFilter=e.magFilter,f.wrapS=e.wrapS,f.wrapT=e.wrapT,f.colorSpace=e.colorSpace,f.name=e.name,ee&&(ee.forceContextLoss(),ee.dispose(),ee=null),f}class Dn{parse(n,t,r,o){this.parseAsync(n,o).then(t).catch(r)}async parseAsync(n,t={}){t=Object.assign({ar:{anchoring:{type:"plane"},planeAnchoring:{alignment:"horizontal"}},includeAnchoringProperties:!0,quickLookCompatible:!1,maxTextureSize:1024},t);const r={},o="model.usda";r[o]=null;let a=He();a+=wn(t);const s={},u={};n.traverseVisible(f=>{if(f.isMesh){const i=f.geometry,c=f.material;if(c.isMeshStandardMaterial){const h="geometries/Geometry_"+i.id+".usda";if(!(h in r)){const v=Sn(i);r[h]=mn(v)}c.uuid in s||(s[c.uuid]=c),a+=yn(f,i,c)}else console.warn("THREE.USDZExporter: Unsupported material type (USDZ only supports MeshStandardMaterial)",f)}else f.isCamera&&(a+=kn(f))}),a+=xn(),a+=Un(s,u,t.quickLookCompatible),r[o]=ae(a),a=null;for(const f in u){let i=u[f];i.isCompressedTexture===!0&&(i=$n(i));const c=Mn(i.image,i.flipY,t.maxTextureSize),h=await new Promise(v=>c.toBlob(v,"image/png",1));r[`textures/Texture_${f}.png`]=new Uint8Array(await h.arrayBuffer())}let l=0;for(const f in r){const i=r[f],c=34+f.length;l+=c;const h=l&63;if(h!==4){const v=64-h,g=new Uint8Array(v);r[f]=[i,{extra:{12345:g}}]}l=i.length}return dn(r,{level:0})}}function Mn(e,n,t){if(typeof HTMLImageElement<"u"&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&e instanceof HTMLCanvasElement||typeof OffscreenCanvas<"u"&&e instanceof OffscreenCanvas||typeof ImageBitmap<"u"&&e instanceof ImageBitmap){const r=t/Math.max(e.width,e.height),o=document.createElement("canvas");o.width=e.width*Math.min(1,r),o.height=e.height*Math.min(1,r);const a=o.getContext("2d");return n===!0&&(a.translate(0,o.height),a.scale(1,-1)),a.drawImage(e,0,0,o.width,o.height),o}else throw new Error("THREE.USDZExporter: No valid image data found. Unable to process texture.")}const T=7;function He(){return`#usda 1.0
(
	customLayerData = {
		string creator = "Three.js USDZExporter"
	}
	defaultPrim = "Root"
	metersPerUnit = 1
	upAxis = "Y"
)

`}function wn(e){return`def Xform "Root"
{
	def Scope "Scenes" (
		kind = "sceneLibrary"
	)
	{
		def Xform "Scene" (
			customData = {
				bool preliminary_collidesWithEnvironment = 0
				string sceneName = "Scene"
			}
			sceneName = "Scene"
		)
		{${e.includeAnchoringProperties===!0?`
		token preliminary:anchoring:type = "${e.ar.anchoring.type}"
		token preliminary:planeAnchoring:alignment = "${e.ar.planeAnchoring.alignment}"
	`:""}
`}function xn(){return`
		}
	}
}

`}function mn(e){let n=He();return n+=e,ae(n)}function yn(e,n,t){const r="Object_"+e.id,o=Le(e.matrixWorld);return e.matrixWorld.determinant()<0&&console.warn("THREE.USDZExporter: USDZ does not support negative scales",e),`def Xform "${r}" (
	prepend references = @./geometries/Geometry_${n.id}.usda@</Geometry>
	prepend apiSchemas = ["MaterialBindingAPI"]
)
{
	matrix4d xformOp:transform = ${o}
	uniform token[] xformOpOrder = ["xformOp:transform"]

	rel material:binding = </Materials/Material_${t.id}>
}

`}function Le(e){const n=e.elements;return`( ${te(n,0)}, ${te(n,4)}, ${te(n,8)}, ${te(n,12)} )`}function te(e,n){return`(${e[n+0]}, ${e[n+1]}, ${e[n+2]}, ${e[n+3]})`}function Sn(e){return`
def "Geometry"
{
${_n(e)}
}
`}function _n(e){const n="Geometry",t=e.attributes,r=t.position.count;return`
	def Mesh "${n}"
	{
		int[] faceVertexCounts = [${Tn(e)}]
		int[] faceVertexIndices = [${Cn(e)}]
		normal3f[] normals = [${$e(t.normal,r)}] (
			interpolation = "vertex"
		)
		point3f[] points = [${$e(t.position,r)}]
${En(t)}
		uniform token subdivisionScheme = "none"
	}
`}function Tn(e){const n=e.index!==null?e.index.count:e.attributes.position.count;return Array(n/3).fill(3).join(", ")}function Cn(e){const n=e.index,t=[];if(n!==null)for(let r=0;r<n.count;r++)t.push(n.getX(r));else{const r=e.attributes.position.count;for(let o=0;o<r;o++)t.push(o)}return t.join(", ")}function $e(e,n){if(e===void 0)return console.warn("USDZExporter: Normals missing."),Array(n).fill("(0, 0, 0)").join(", ");const t=[];for(let r=0;r<e.count;r++){const o=e.getX(r),a=e.getY(r),s=e.getZ(r);t.push(`(${o.toPrecision(T)}, ${a.toPrecision(T)}, ${s.toPrecision(T)})`)}return t.join(", ")}function Pn(e){const n=[];for(let t=0;t<e.count;t++){const r=e.getX(t),o=e.getY(t);n.push(`(${r.toPrecision(T)}, ${1-o.toPrecision(T)})`)}return n.join(", ")}function En(e){let n="";for(let r=0;r<4;r++){const o=r>0?r:"",a=e["uv"+o];a!==void 0&&(n+=`
		texCoord2f[] primvars:st${o} = [${Pn(a)}] (
			interpolation = "vertex"
		)`)}const t=e.color;if(t!==void 0){const r=t.count;n+=`
	color3f[] primvars:displayColor = [${$e(t,r)}] (
		interpolation = "vertex"
		)`}return n}function Un(e,n,t=!1){const r=[];for(const o in e){const a=e[o];r.push(An(a,n,t))}return`def "Materials"
{
${r.join("")}
}

`}function An(e,n,t=!1){const r="			",o=[],a=[];function s(u,l,f){const i=u.source.id+"_"+u.flipY;n[i]=u;const c=u.channel>0?"st"+u.channel:"st",h={1e3:"repeat",1001:"clamp",1002:"mirror"},v=u.repeat.clone(),g=u.offset.clone(),$=u.rotation,x=Math.sin($),E=Math.cos($);return g.y=1-g.y-v.y,t?(g.x=g.x/v.x,g.y=g.y/v.y,g.x+=x/v.x,g.y+=E-1):(g.x+=x*v.x,g.y+=(1-E)*v.y),`
		def Shader "PrimvarReader_${l}"
		{
			uniform token info:id = "UsdPrimvarReader_float2"
			float2 inputs:fallback = (0.0, 0.0)
			token inputs:varname = "${c}"
			float2 outputs:result
		}

		def Shader "Transform2d_${l}"
		{
			uniform token info:id = "UsdTransform2d"
			token inputs:in.connect = </Materials/Material_${e.id}/PrimvarReader_${l}.outputs:result>
			float inputs:rotation = ${($*(180/Math.PI)).toFixed(T)}
			float2 inputs:scale = ${ke(v)}
			float2 inputs:translation = ${ke(g)}
			float2 outputs:result
		}

		def Shader "Texture_${u.id}_${l}"
		{
			uniform token info:id = "UsdUVTexture"
			asset inputs:file = @textures/Texture_${i}.png@
			float2 inputs:st.connect = </Materials/Material_${e.id}/Transform2d_${l}.outputs:result>
			${f!==void 0?"float4 inputs:scale = "+Rn(f):""}
			token inputs:sourceColorSpace = "${u.colorSpace===en?"raw":"sRGB"}"
			token inputs:wrapS = "${h[u.wrapS]}"
			token inputs:wrapT = "${h[u.wrapT]}"
			float outputs:r
			float outputs:g
			float outputs:b
			float3 outputs:rgb
			${e.transparent||e.alphaTest>0?"float outputs:a":""}
		}`}return e.side===Ke&&console.warn("THREE.USDZExporter: USDZ does not support double sided materials",e),e.map!==null?(o.push(`${r}color3f inputs:diffuseColor.connect = </Materials/Material_${e.id}/Texture_${e.map.id}_diffuse.outputs:rgb>`),e.transparent?o.push(`${r}float inputs:opacity.connect = </Materials/Material_${e.id}/Texture_${e.map.id}_diffuse.outputs:a>`):e.alphaTest>0&&(o.push(`${r}float inputs:opacity.connect = </Materials/Material_${e.id}/Texture_${e.map.id}_diffuse.outputs:a>`),o.push(`${r}float inputs:opacityThreshold = ${e.alphaTest}`)),a.push(s(e.map,"diffuse",e.color))):o.push(`${r}color3f inputs:diffuseColor = ${Re(e.color)}`),e.emissiveMap!==null?(o.push(`${r}color3f inputs:emissiveColor.connect = </Materials/Material_${e.id}/Texture_${e.emissiveMap.id}_emissive.outputs:rgb>`),a.push(s(e.emissiveMap,"emissive",new j(e.emissive.r*e.emissiveIntensity,e.emissive.g*e.emissiveIntensity,e.emissive.b*e.emissiveIntensity)))):e.emissive.getHex()>0&&o.push(`${r}color3f inputs:emissiveColor = ${Re(e.emissive)}`),e.normalMap!==null&&(o.push(`${r}normal3f inputs:normal.connect = </Materials/Material_${e.id}/Texture_${e.normalMap.id}_normal.outputs:rgb>`),a.push(s(e.normalMap,"normal"))),e.aoMap!==null&&(o.push(`${r}float inputs:occlusion.connect = </Materials/Material_${e.id}/Texture_${e.aoMap.id}_occlusion.outputs:r>`),a.push(s(e.aoMap,"occlusion",new j(e.aoMapIntensity,e.aoMapIntensity,e.aoMapIntensity)))),e.roughnessMap!==null?(o.push(`${r}float inputs:roughness.connect = </Materials/Material_${e.id}/Texture_${e.roughnessMap.id}_roughness.outputs:g>`),a.push(s(e.roughnessMap,"roughness",new j(e.roughness,e.roughness,e.roughness)))):o.push(`${r}float inputs:roughness = ${e.roughness}`),e.metalnessMap!==null?(o.push(`${r}float inputs:metallic.connect = </Materials/Material_${e.id}/Texture_${e.metalnessMap.id}_metallic.outputs:b>`),a.push(s(e.metalnessMap,"metallic",new j(e.metalness,e.metalness,e.metalness)))):o.push(`${r}float inputs:metallic = ${e.metalness}`),e.alphaMap!==null?(o.push(`${r}float inputs:opacity.connect = </Materials/Material_${e.id}/Texture_${e.alphaMap.id}_opacity.outputs:r>`),o.push(`${r}float inputs:opacityThreshold = 0.0001`),a.push(s(e.alphaMap,"opacity"))):o.push(`${r}float inputs:opacity = ${e.opacity}`),e.isMeshPhysicalMaterial&&(e.clearcoatMap!==null?(o.push(`${r}float inputs:clearcoat.connect = </Materials/Material_${e.id}/Texture_${e.clearcoatMap.id}_clearcoat.outputs:r>`),a.push(s(e.clearcoatMap,"clearcoat",new j(e.clearcoat,e.clearcoat,e.clearcoat)))):o.push(`${r}float inputs:clearcoat = ${e.clearcoat}`),e.clearcoatRoughnessMap!==null?(o.push(`${r}float inputs:clearcoatRoughness.connect = </Materials/Material_${e.id}/Texture_${e.clearcoatRoughnessMap.id}_clearcoatRoughness.outputs:g>`),a.push(s(e.clearcoatRoughnessMap,"clearcoatRoughness",new j(e.clearcoatRoughness,e.clearcoatRoughness,e.clearcoatRoughness)))):o.push(`${r}float inputs:clearcoatRoughness = ${e.clearcoatRoughness}`),o.push(`${r}float inputs:ior = ${e.ior}`)),`
	def Material "Material_${e.id}"
	{
		def Shader "PreviewSurface"
		{
			uniform token info:id = "UsdPreviewSurface"
${o.join(`
`)}
			int inputs:useSpecularWorkflow = 0
			token outputs:surface
		}

		token outputs:surface.connect = </Materials/Material_${e.id}/PreviewSurface.outputs:surface>

${a.join(`
`)}

	}
`}function Re(e){return`(${e.r}, ${e.g}, ${e.b})`}function Rn(e){return`(${e.r}, ${e.g}, ${e.b}, 1.0)`}function ke(e){return`(${e.x}, ${e.y})`}function kn(e){const n=e.name?e.name:"Camera_"+e.id,t=Le(e.matrixWorld);return e.matrixWorld.determinant()<0&&console.warn("THREE.USDZExporter: USDZ does not support negative scales",e),e.isOrthographicCamera?`def Camera "${n}"
		{
			matrix4d xformOp:transform = ${t}
			uniform token[] xformOpOrder = ["xformOp:transform"]

			float2 clippingRange = (${e.near.toPrecision(T)}, ${e.far.toPrecision(T)})
			float horizontalAperture = ${((Math.abs(e.left)+Math.abs(e.right))*10).toPrecision(T)}
			float verticalAperture = ${((Math.abs(e.top)+Math.abs(e.bottom))*10).toPrecision(T)}
			token projection = "orthographic"
		}
	
	`:`def Camera "${n}"
		{
			matrix4d xformOp:transform = ${t}
			uniform token[] xformOpOrder = ["xformOp:transform"]

			float2 clippingRange = (${e.near.toPrecision(T)}, ${e.far.toPrecision(T)})
			float focalLength = ${e.getFocalLength().toPrecision(T)}
			float focusDistance = ${e.focus.toPrecision(T)}
			float horizontalAperture = ${e.getFilmWidth().toPrecision(T)}
			token projection = "perspective"
			float verticalAperture = ${e.getFilmHeight().toPrecision(T)}
		}
	
	`}export{Dn as USDZExporter};
